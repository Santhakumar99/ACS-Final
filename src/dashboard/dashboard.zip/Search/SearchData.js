import React from "react";
import "../../dashboard/Search/Search.css";
import { useEffect, useState } from "react";
import { TextField } from "@material-ui/core";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import axios from "axios";
const SearchData = () => {
  const [values, setValues] = useState({
    name: "",
    mobile: "",
    icNumber: "",
    // loan details
    loanId: "",
    loanAmount: "",
    tenure: "",
    productType: "",
    fromDate: "",
    toDate: "",
    overdue: "",
    approver: "", // not yet done
    prepared: "",
  });
  //-------------------- onchange handle Project------------------

  const onChangeHandler = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    let inputValues = values;
    inputValues[name] = value;
    setValues({ ...inputValues });
  };
  const AddHandleProducts = async (e) => {
    e.preventDefault();
    // setIsLoading(true);
    try {
      let vals = values;
      const valuesObj = {
        ...vals,
      };
      console.log(valuesObj);
      const Result = await axios.post(
        `${process.env.REACT_APP_URL}/usertypes`,
        valuesObj,
        {
          headers: {
            Authorization: localStorage.getItem("token"),
          },
        }
      );
      console.log(Result);
      // setProducts(Result);
      // setIsLoading(false);
      // handleClickOpen("Role Created Successfully");
      // return (window.location = "/listRoles");
    } catch (error) {
      console.log(error);
      // setIsLoading(false);
      // error != null &&
      // error.response != null &&
      // error.response.data != null &&
      // error.response.data.errors[0]
      //   ? handleClickOpen(
      //       error != null &&
      //         error.response != null &&
      //         error.response.data != null &&
      //         error.response.data.errors[0] &&
      //         error.response.data.errors[0].msg
      //     )
      //   : handleClickOpen("Something went wrong !!!");
    }
    // closeForm();
  };
  return (
    <div>
      <div className="search-head" style={{ marginTop: "50px" }}>
        <h1 style={{ fontSize: "25px", padding: "10px" }}>Search</h1>

        <div className="container">
          <div className="Search-head">
            <div className="row">
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                {/* <label>Loan Id</label> */}
                {/* <input
                    type="text"
                    name="product"
                    id="product"
                    // value={values.product}
                    // onChange={(e) => onChangeHandler(e)}
                    className="form-control"
                    placeholder="Product"
                    required
                  /> */}
                <TextField
                  label="Loan Id"
                  size="small"
                  type="text"
                  fullWidth
                  variant="outlined"
                  value={values.loanId}
                  // onChange={(event) => setOldPassword(event.target.value)}
                  required
                  autoFocus
                />
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                {/* <label>IC Number</label> */}
                <TextField
                  label="IC Number"
                  size="small"
                  type="number"
                  fullWidth
                  variant="outlined"
                  value={values.icNumber}
                  // onChange={(event) => setOldPassword(event.target.value)}
                  required
                  autoFocus
                />
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                {/* <label>Name</label> */}
                <TextField
                  label="Name"
                  size="small"
                  type="text"
                  fullWidth
                  variant="outlined"
                  value={values.name}
                  // onChange={(event) => setOldPassword(event.target.value)}
                  // required
                  autoFocus
                />
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                {/* <label>Phone number</label> */}
                <TextField
                  label="Phone number"
                  size="small"
                  type="number"
                  fullWidth
                  variant="outlined"
                  // value={oldPassword}
                  // onChange={(event) => setOldPassword(event.target.value)}
                  required
                  autoFocus
                />
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                {/* <label>Loan amount</label> */}
                <TextField
                  label="Loan amount"
                  size="small"
                  type="text"
                  fullWidth
                  variant="outlined"
                  value={values.loanAmount}
                  // onChange={(event) => setOldPassword(event.target.value)}
                  required
                  autoFocus
                />
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    ACS score
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={2}>2</MenuItem>
                    <MenuItem value={3}>3</MenuItem>
                    <MenuItem value={4}>4</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={6}>6</MenuItem>
                    <MenuItem value={7}>7</MenuItem>
                    <MenuItem value={8}>8</MenuItem>
                    <MenuItem value={9}>9</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                  </Select>
                </FormControl>
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Product
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values.productType}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>BNPL</MenuItem>
                    <MenuItem value={20}>Quad Hasan</MenuItem>
                  </Select>
                </FormControl>
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Approver
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values.approver}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>30+ DPD</MenuItem>
                    <MenuItem value={20}>60+ DPD</MenuItem>
                    <MenuItem value={30}>90+ DPD</MenuItem>
                    <MenuItem value={30}>120+ DPD</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Preparer
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values.prepared}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>30+ DPD</MenuItem>
                    <MenuItem value={20}>60+ DPD</MenuItem>
                    <MenuItem value={30}>90+ DPD</MenuItem>
                    <MenuItem value={30}>120+ DPD</MenuItem>
                  </Select>
                </FormControl>
              </div>
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Date
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values.fromDate}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>Ten</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={30}>Thirty</MenuItem>
                  </Select>
                </FormControl>
              </div>
              {/* <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Age
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={age}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>Ten</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={30}>Thirty</MenuItem>
                  </Select>
                </FormControl>
              </div> */}
              <div className="col-lg-4 col-md-4 col-sm-12 search-field">
                <FormControl sx={{ m: 1, minWidth: 120 }}>
                  <InputLabel id="demo-simple-select-helper-label">
                    Over Due
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={values.overdue}
                    label="Age"
                    onChange={onChangeHandler}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>30+ DPD</MenuItem>
                    <MenuItem value={20}>60+ DPD</MenuItem>
                    <MenuItem value={30}>90+ DPD</MenuItem>
                    <MenuItem value={30}>120+ DPD</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
            <div>
              <button type="button" className="btn btn-primary search">
                Filter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchData;
