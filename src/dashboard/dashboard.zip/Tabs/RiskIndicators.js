// import React from "react";
// import "../Css/Loanperformance.css";
// const RiskIndicators = () => {
//   const cardStyle = {
//     padding: "10px",
//     fontFamily: "Arial",
//   };
//   return (
//     <div>
//       <div style={{ padding: "10px" }} className="card LoanPerformance">
//         <div className="card-title">Loan Performance</div>
//         <div style={cardStyle} className="row">
//           <div className="col-lg-6 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   Early alerts raised (volume and value)
//                 </div>
//                 {/* <CardCount /> */}
//               </div>
//             </div>
//           </div>
//           <div className="col-lg-6 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   List of app users with deteriorating ACS score 10% [watch
//                   list]
//                 </div>
//                 {/* <CardCount /> */}
//               </div>
//             </div>
//           </div>
//         </div>
//         <div style={cardStyle} className="row">
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   List of defaulters in 60+ DPD and longer
//                 </div>
//                 {/* <CardCount /> */}
//               </div>
//             </div>
//           </div>
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   Concentration risk ie more than 20% of loans
//                 </div>
//                 {/* <CardCount /> */}
//               </div>
//             </div>
//           </div>
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   {" "}
//                   Restructured loans – volume and value
//                 </div>
//                 {/* <CardCount /> */}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//       <div style={{ padding: "10px" }} className="card LoanPerformance">
//         <div className="card-title">App Performance</div>
//         <div className="row">
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">App live performance/ downtime</div>
//               </div>
//             </div>
//           </div>
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">
//                   # of security/ vulnerability issues
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="col-lg-4 col-md-12 col-sm-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="card-title">No of complaints by users</div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default RiskIndicators;
