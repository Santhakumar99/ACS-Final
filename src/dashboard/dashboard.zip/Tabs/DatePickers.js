import React from "react";
import { useEffect, useState } from "react";
import "../Css/Loanperformance.css";
const DatePickers = () => {
  const [values, setValues] = useState({
    startdate: "",
    enddate: "",
  });
  const onChangeHandler = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    let inputValues = values;
    inputValues[name] = value;
    setValues({ ...inputValues });
  };
  const FilterData = () => {
    const valuesObj = {
      ...values,
    };
    console.log(valuesObj);
  };
  return (
    <div>
      <div className="d-picker">
        <div className="Fromdate">
          <span className="date-content">From</span>
          <input
            type="date"
            name="startdate"
            max={values.enddate}
            id="startdate"
            value={values.startdate}
            onChange={(e) => onChangeHandler(e)}
            className="form-control"
          />
          <span className="date-content">To</span>
          <input
            type="date"
            name="enddate"
            min={values.startdate}
            max={values.enddate}
            id="enddate"
            value={values.enddate}
            onChange={(e) => onChangeHandler(e)}
            className="form-control"
          />
          <div className="contact-us-form-group DashdateSubmit">
            <button
              className="contact-us-form-btn"
              style={{ marginLeft: "20px", marginTop: "-5px" }}
              onClick={FilterData}
            >
              Filter
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatePickers;
